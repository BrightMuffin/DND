package rpg.ifgoiano.rpg.controle;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import rpg.ifgoiano.rpg.service.PersService;
import rpg.ifgoiano.rpg.service.PersServiceImpl;

public class PersController {
    
}
