package rpg.ifgoiano.rpg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rpg.ifgoiano.rpg.entidade.Personagem;
import rpg.ifgoiano.rpg.repositorio.PersRepositorio;


public class PersServiceImpl implements PersService{
    
    @Autowired
    private PersRepositorio persrepositorio;
    
    
    public List<Personagem> listarPersona(){
        return persrepositorio.findAll();
    }   

}
